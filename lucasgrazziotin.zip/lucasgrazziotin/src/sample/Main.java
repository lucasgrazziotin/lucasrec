package sample;
public class Main {

    public static void main(String[] args) {
        System.out.println("vou andar de carro");
        Carro carro1 = new Carro();
        carro1.setNome("camaro");
        carro1.setPreço(5000);

        Carro carro2 = new Carro();
        carro2.setNome("ferrari");
        carro2.setPreço(8000);

        Carro carro3 = new Carro();
        carro3.setNome("tesla");
        carro3.setPreço(9000);


        System.out.println(carro1);
        System.out.println(carro2);
        System.out.println(carro3);
    }
}
