package lucasgrazziotin;

public class Carro {
    private String nome;
    private double preco;

    public Carro(){ }


    public Carro(String nome, String, double preco){
        this.nome = nome;
        this.preco = preco;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreço() {
        return preco;
    }

    public void setPreço(double preço) {
        this.preco = preço;
    }
    @Override
    public String toString(){
        return "carro:" + nome
                + " preço: " + preco;
    }
}